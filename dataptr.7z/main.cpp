#include <ntifs.h>
#include <ntddk.h>
#include <classpnp.h>
#include <windef.h>
#include <ntimage.h>
#include "sk.hpp"
#include "util.hpp"
#include "kli.hpp"
#include "comm.hpp"
#include "hook.hpp"
#include "cr3.hpp"

ULONGLONG m_stored_dtb;

extern "C" PVOID NTAPI PsGetProcessSectionBaseAddress(PEPROCESS Process);

__int64 __fastcall hkNtUserDragObject(void* a1) {
	hyzr_cmd* commands = reinterpret_cast<hyzr_cmd*>(a1);

	if (commands->verification_code != SYSCALL_CODE)
		return originalNtUserDragObject(a1);

	// passes
	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", commands->pid);
	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", commands->operation);
	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", commands->);
	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", (__int64)a1);
	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", (__int64)a1);
	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", (__int64)a1);
	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", (__int64)a1);

	if (commands->operation == memory_read) {
		if (!commands->pid || !commands->address || !commands->size) {
			commands->buffer = 0;
			return 0;
		}
		PEPROCESS process = NULL;
		qtx_import(PsLookupProcessByProcessId)((HANDLE)commands->pid, &process);
		if (!process) {
			commands->buffer = 0;
			return 0;
		}
		INT64 physicaladdress;
		physicaladdress = pml4::translate_linear(m_stored_dtb, (ULONG64)(commands->address));
		if (!physicaladdress) {
			return 0;
		}
		ULONG64 finalsize = find_min(PAGE_SIZE - (physicaladdress & 0xFFF), commands->size);
		SIZE_T bytestrough = NULL;
		read_physical(PVOID(physicaladdress), (PVOID)((ULONG64)(commands->buffer)), finalsize, &bytestrough);
		
		return 0;
	}

	if (commands->operation == module_base) {
		if (!commands->pid) {
			commands->base_address = 0;
			return 0;
		}

		PEPROCESS process = NULL;
		qtx_import(PsLookupProcessByProcessId)((HANDLE)commands->pid, &process);
		if (!process) {
			commands->base_address = 0;
			return 0;
		}
		ULONGLONG baseimg = (ULONGLONG)PsGetProcessSectionBaseAddress(process);
		if (!baseimg) {
			commands->base_address = 0;
			return 0;
		}

		commands->base_address = baseimg;

		ObDereferenceObject(process);
		return 0;
	}
	if (commands->operation == memory_cr3) {
		if (!commands->pid || !commands->known_offset) {
			commands->dtb = 0;
			return 0;
		}
		PEPROCESS process = NULL;
		qtx_import(PsLookupProcessByProcessId)((HANDLE)commands->pid, &process);
		if (!process) {
			commands->dtb = 0;
			return 0;
		}
		PVOID baseimg = (void*)PsGetProcessSectionBaseAddress(process);
		if (!baseimg) {
			commands->dtb = 0;
			return 0;
		}
		ObDereferenceObject(process);

		m_stored_dtb = pml4::dirbase_from_base_address(baseimg, commands->known_offset);

		commands->dtb = m_stored_dtb;
		//DbgPrintEx(0, 0, "[+] DTB @ 0x%llu\n", m_stored_dtb);

		return 0;
	}

	//DbgPrintEx(0, 0, "[+] hkNtUserDragObject called with 0x%llu\n", (__int64)a1);
	return 0;
}


extern "C" NTSTATUS DriverEntry()
{
	if (NT_SUCCESS(pml4::InitializeMmPfnDatabase())) {
		//DbgPrintEx(0, 0, "[+] Successfully InitializeMmPfnDatabase\n");
	}
	else {
		//DbgPrintEx(0, 0, "[+] Could not InitializeMmPfnDatabase\n");
		return STATUS_UNSUCCESSFUL;
	}

	const uintptr_t win32k = utils::get_kernel_module(_("win32k.sys"));
	uintptr_t nt_qword{};

	if (win32k) {
		nt_qword = utils::pattern_scan(win32k, NT_QWORD_SIG, NT_QWORD_MASK);
	}

	else {
		//DbgPrintEx(0, 0, "[-] win32k.sys not found\n");
		return STATUS_UNSUCCESSFUL;
	}

	//DbgPrintEx(0, 0, "[+] win32k.sys @ 0x%llu\n", win32k);
	//DbgPrintEx(0, 0, "[+] nt_qword @ 0x%llu\n", nt_qword);

	PEPROCESS process_target{};

	if (utils::find_process(_("explorer.exe"), &process_target) == STATUS_SUCCESS && process_target) {
		const uintptr_t nt_qword_deref = (uintptr_t)nt_qword + *(int*)((BYTE*)nt_qword + 3) + 7;

		//DbgPrintEx(0, 0, "[+] *nt_qword @ 0x%llu\n", nt_qword_deref);

		KeAttachProcess(process_target);
		*(void**)&originalNtUserDragObject = _InterlockedExchangePointer((void**)nt_qword_deref, (void*)hkNtUserDragObject);
		KeDetachProcess();
	}

	else {
		//DbgPrintEx(0, 0, "[-] Can't find explorer.exe\n");
		return STATUS_UNSUCCESSFUL;
	}

	//DbgPrintEx(0, 0, "[+] Driver loaded\n");
	return STATUS_SUCCESS;
}
