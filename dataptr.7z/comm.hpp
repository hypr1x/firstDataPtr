#include "def.h"

#define SYSCALL_CODE 0x9273456B

enum what_we_doin : int
{
	memory_read = 0,
	memory_cr3,
	module_base,
};

struct hyzr_cmd
{
	unsigned int verification_code = 0;
	what_we_doin operation;
	ULONG64 buffer;
	ULONG64	address;
	ULONG size;
	ULONG pid;
	ULONG64 base_address;
	ULONG64 dtb;
	ULONG64 known_offset;
};